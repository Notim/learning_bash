vash-express-example
====================

An example express app built using Vash